#ifndef __bitset__
#define __bitset__

// Should be opaque -- i.e., should not be defined here
typedef unsigned long bitset;

// Operations on individual bits in a set
void    set    (bitset *bits, int index);
void    unset  (bitset *bits, int index);
int     isset  (const bitset *bits, int index);

// Operations on entire sets
bitset *setAnd (const bitset *bits, const bitset *moreBits); 
bitset *setOr  (const bitset *bits, const bitset *moreBits);
bitset *setXor (const bitset *bits, const bitset *moreBits);

// Creator and inspector
bitset *mkBitset(int element_count, ...);
void    print(const bitset* bits);

#endif
