#include <stdlib.h>
#include "bitset.h"

// Usage: ./bs +1 +2 -2 -3 ==> { 1, 3 }
// All +n goes into set p
// All -n goes into set n
// The printed result is the xor of p and n
int main(int argc, char *argv[]) {
  bitset *p = mkBitset(0);
  bitset *n = mkBitset(0);
  while (*++argv) {
    char modifier = *((*argv)++); 
    int index = atoi(*argv);
    switch (modifier) {
    case '-': set(n, index); break;
    case '+': set(p, index); break;
    }
  }
  print(setXor(p,n));
  return 0;
}
