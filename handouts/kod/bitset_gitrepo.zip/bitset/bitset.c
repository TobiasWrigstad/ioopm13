#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "bitset.h"

// ================================================================
// bitset.c 
// Implements a set of integers using bit operations
// Written to demonstrate:
// - bit operations
// - variable argument lists
// - macros
// - consts
// - function pointers (a bit contrieved)
// ================================================================

/* ================================================================
   TODO:
   [x] Define the set data structure as a sequence of N bits
   [x] Define a constructor for sets
   [x] Operations on individual bits:
       [x] Set a bit 
       [x] Unset a bit
       [x] Read a bit
       [x] Show alternative implementation with enums (maybe messier)
   [x] Operations on entire bit sets:
       [x] Set union
       [x] Set intersection
       [x] Set xor 
   [x] Defensive programming with asserts
   [x] Define a print operation on sets { 1, 3, 9, 12, ... }
   [x] Add const declarations in suitable places
   [x] Rewrite _setop to work with function pointers instead
   ================================================================ */

typedef bitset(*binop_bitset)(bitset, bitset);
typedef enum { set_op, unset_op, read_op } bit_op; 
typedef enum { union_op, intersection_op, xor_op } bitset_op; 

#define ELEMENTS          128
#define BITS_PER_ELEMENT  (sizeof(bitset) * 8)
#define ARRAY_SIZE        (ELEMENTS / BITS_PER_ELEMENT)
#define ONE               1UL

#define mask(num)          (ONE << (num % BITS_PER_ELEMENT)) 
#define element(bits, num) (bits[num / BITS_PER_ELEMENT])

#define assertTrue(arg, msg) \
  do { \
    if (!(arg)) {							\
      printf("%s:%d Failed: (%s) %s\n", __FILE__, __LINE__, #arg, msg); \
      abort(); \
    } \
  } while (0); 
#define assertFalse(arg, msg) assertTrue((!arg), msg); 
#define fail(msg)             assertTrue(0, msg); 

bitset *mkBitset(int element_count, ...) {
  assertTrue(element_count >= 0, "mkBitset called with negative number of elements");
  assertTrue(element_count < ELEMENTS, "mkBitset called with too many elements");

  bitset *bits = calloc(ARRAY_SIZE, sizeof(bitset));
  assertTrue(bits, "NULL result from calloc -- probably ran out of memory");

  va_list elements;
  va_start(elements, element_count);
  while(element_count--) {
    set(bits, va_arg(elements, int)); 
  }
  va_end(elements);

  return bits;
}

static int _bitop(bitset *b, int idx, bit_op bop) {
  assertTrue(idx >= 0, "Asking for negative element in set");
  assertTrue(idx < ELEMENTS, "Asking for too large element in set");

  switch(bop) {
  case set_op:   element(b, idx) |=  mask(idx); return 0;
  case unset_op: element(b, idx) &= ~mask(idx); return 0;
  case read_op:                                 return element(b, idx) & mask(idx); 
  default: fail("Unreachable default reached"); return -1;
  }
}

static bitset *_setop(const bitset *lhs, bitset_op bsop, const bitset *rhs) {
  assertTrue(lhs, "Set operation on NULL set (lhs)");
  assertTrue(rhs, "Set operation on NULL set (rhs)");

  bitset *result = mkBitset(0);
  for (int i = 0; i < ARRAY_SIZE; ++i) {
    switch (bsop) {
    case union_op:         result[i] = lhs[i] | rhs[i];    break;
    case intersection_op:  result[i] = lhs[i] & rhs[i];    break;
    case xor_op:           result[i] = lhs[i] ^ rhs[i];    break;
    default: fail("Unreachable default reached");          return NULL;
    }
  }
  return result;
}

static bitset *_setop_fun(const bitset *lhs, binop_bitset binop, const bitset *rhs) {
  bitset *result = mkBitset(0); 
  for (int i = 0; i < ELEMENTS; ++i) { 
    result[i] = binop(lhs[i], rhs[i]); 
  }
  return result;
}

void print(const bitset* bits) {
  printf("{ ");
  char *pad = "";
  for (int i = 0; i < ELEMENTS; ++i) {
    if (isset(bits, i)) {
      printf("%s%d", pad, i);
      pad = ", ";
    }
  }
  printf(" }\n");
}

void set   (bitset *bits, int index)       {        _bitop(bits, index, set_op);   }
void unset (bitset *bits, int index)       {        _bitop(bits, index, unset_op); }
int isset  (const bitset *bits, int index) { return _bitop(bits, index, read_op);  } // (**)

// (**) Will warn since _bitop cannot be declared as const, but is safe in practise. 
//      Now that we also capture 'constness', the _bitop function makes less safe,
//      at least from a static typing-POV.   

// Retired to demonstrate function pointers
bitset *deprecated_setAnd (const bitset *lhs, const bitset *rhs) { return _setop(lhs, union_op,        rhs ); }
bitset *deprecated_setOr  (const bitset *lhs, const bitset *rhs) { return _setop(lhs, intersection_op, rhs ); }
bitset *deprecated_setXor (const bitset *lhs, const bitset *rhs) { return _setop(lhs, xor_op,          rhs ); }

bitset binop_and(bitset a, bitset b) { return a & b; }
bitset binop_or (bitset a, bitset b) { return a | b; }
bitset binop_xor(bitset a, bitset b) { return a ^ b; }

bitset *s-etAnd (const bitset *lhs, const bitset *rhs) { return _setop_fun(lhs, binop_and, rhs ); }
bitset *setOr  (const bitset *lhs, const bitset *rhs) { return _setop_fun(lhs, binop_or,  rhs ); }
bitset *setXor (const bitset *lhs, const bitset *rhs) { return _setop_fun(lhs, binop_xor, rhs ); }

